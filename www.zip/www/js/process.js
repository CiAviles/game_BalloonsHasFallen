
var w = 500; var h = 710;
var game = new Phaser.Game(w, h, Phaser.CANVAS, '', { preload: preload, create: create, update: update});
var player, cursors,dart,darts, explodes;
var redBalloons, redBalloon,yellowBalloons,yellowBalloon,blueBalloons,blueBalloon, granada,scoreText,gameOverText, bestText,fireButton, buttonRight, buttonLeft;
var score = 0,dartTime = 0;

// var bounds = 500;

function preload() {
    game.scale.maxWidth = 600;
    game.scale.maxHeight = 790;
    game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
    game.scale.setScreenSize();

    game.load.image('sky', 'assets/background.png');
    game.load.image('ground', 'assets/platform.png');
    game.load.image('redBalloon', 'assets/redBalloon.png');
    game.load.image('yellowBalloon', 'assets/yellowBalloon.png');
    game.load.image('blueBalloon', 'assets/blueBalloon.png');
    // game.load.image('granada', 'assets/granada.png');
    game.load.image('dart', 'assets/dart.png');
    game.load.image('player1', 'assets/dart.png');
    game.load.spritesheet('right', 'assets/right.png', 128, 128);
    game.load.spritesheet('left', 'assets/left.png', 128, 128);
    game.load.spritesheet('fire', 'assets/fire2.png', 128, 128);
    game.load.spritesheet('boom', 'assets/boom.png', 50, 50);
    game.load.spritesheet('yboom', 'assets/yellowboom.png', 50, 50);
    game.load.spritesheet('bboom', 'assets/blueboom.png', 50, 50);
    game.load.spritesheet('granade', 'assets/explode.png', 128, 128);
    game.load.spritesheet('pause', 'assets/pause.png', 128, 128);

}


function create() {
    game.physics.startSystem(Phaser.Physics.ARCADE);

    game.add.sprite(0,0, 'sky');
    player = game.add.sprite(w/2, game.world.height - 150, 'player1');
    player.scale.x = .70;
    player.scale.y = .70;
    player.anchor.setTo(0.5, 0.5);
    
    game.physics.arcade.enable(player);
    player.body.collideWorldBounds = true;

    cursors = game.input.keyboard.createCursorKeys();
    
    createBlueBalloon();
    createRedBalloon();
    createYellowBalloon();
    // createGranada();

    blueBalloon = game.add.sprite("blueBalloon");
    redBalloon = game.add.sprite("redBalloon");
    yellowBalloon = game.add.sprite("yellowBalloon");
    granada = game.add.sprite("granada");

    platform = game.add.group();
    platform.enableBody = true;
    platforms = platform.create(0,510,"ground");
    platforms.body.immovable = true;
    platforms.scale.x = 1.25;
    platforms.scale.y = .2;

    darts = game.add.group();
    darts.enableBody = true;
    darts.createMultiple(30, 'dart');
    darts.setAll('anchor.x', 0.5);
    darts.setAll('anchor.y', 1);
    game.physics.arcade.enable(darts);
    game.physics.arcade.enable(redBalloon);
    game.physics.arcade.enable(yellowBalloon);
    game.physics.arcade.enable(blueBalloon);
    // game.physics.arcade.enable(granada);


    redBalloon = game.add.group();
    redBalloon.enableBody = true;
    blueBalloon = game.add.group();
    blueBalloon.enableBody = true;
    yellowBalloon = game.add.group();
    yellowBalloon.enableBody = true;
    granada = game.add.group();
    granada.enableBody = true;


    scoreText = game.add.text(16, 530, 'Score: 0', { fontSize: '1px', fill: 'white'});
    scoreText.scale.x = .80;
    scoreText.scale.y = .80;
    bestText = game.add.text(380,530, 'Best: '+getData()   ,{fontSize:'1px', fill: 'yellow'});
    bestText.scale.x = .80;
    bestText.scale.y = .80;

    game.input.addPointer();
    gameOverText = game.add.text((w/2)-80,(h/2)-80,"", {align:'centerX',align: "center", fontSize:'1px', fill: 'red'});
    gameRestartText = game.add.text((w/2)-80,(h/2)-120,"", {align:'centerX',align: "center",  fontSize:'1px', fill: 'yellow'});
    // gameOverText.scale.x = .80;
    // gameOverText.scale.y = .80;
    // explode = game.a
    explodesR = game.add.group();
    explodesR.scale.x = 1.1;
    explodesR.scale.y = 1.1;
    explodesR.createMultiple(3, 'boom');
    explodesR.forEach(player1, this);

    explodesY = game.add.group();
    explodesY.scale.x = 1.1;
    explodesY.scale.y = 1.1;
    explodesY.createMultiple(3, 'yboom');
    explodesY.forEach(player1, this);

    explodesB = game.add.group();
    explodesB.scale.x = 1.1;
    explodesB.scale.y = 1.1;
    explodesB.createMultiple(3, 'bboom');
    explodesB.forEach(player1, this);

    explodesG = game.add.group();
    explodesG.scale.x = 1.1;
    explodesG.scale.y = 1.1;
    explodesG.createMultiple(16, 'granade');
    explodesG.forEach(player1, this);
    buttonRight = game.add.button(150, 590, 'right', right);
    buttonRight.scale.x = .8;
    buttonRight.scale.y = .8;
    buttonLeft = game.add.button(20, 590, 'left', left);
    buttonLeft.scale.x = .8;
    buttonLeft.scale.y = .8;
    fireButton = game.add.button(380, 590, 'fire', fire);
    fireButton.scale.x = .8;
    fireButton.scale.y = .8;
    var pause = game.add.button(420, 0, 'pause',pause, this, 1, 0);
    var restart = game.add.button(0,0, '',restart);
    pause.scale.x = .6;
    pause.scale.y = .6;

    pause.events.onInputUp.add(function () {
        pause.frame = 0;
        game.paused = true;
    });
        pause.frame = 1;
    game.input.onDown.add(unpause, self);
    function unpause(event){
    if(game.paused){
        game.paused = false;
        }
        pause.frame = 1;
    }
    // function unpause(event){
    // if(game.paused){
    //     game.paused = true;
    //     }
    //     pause.frame = 0;
    // }


}
function player1(player1){
    player1.anchor.x = 0.5;
    player1.anchor.y = 0.5;
    player1.animations.add('boom');
    player1.animations.add('yboom');
    player1.animations.add('bboom');
    player1.animations.add('granade');
}
function update() {

    game.physics.arcade.collide(player, blueBalloons);
    game.physics.arcade.collide(player, redBalloons);
    game.physics.arcade.collide(player, yellowBalloons);
    // game.physics.arcade.collide(player, granada);
    
    game.physics.arcade.overlap(dart, blueBalloon, collectBlue);
    game.physics.arcade.overlap(dart, redBalloon, collectRed);
    game.physics.arcade.overlap(dart, yellowBalloon, collectYellow);   
    // game.physics.arcade.overlap(dart, granada, collectGranada);   
    game.physics.arcade.overlap(platforms, blueBalloon, overlapBlue);
    game.physics.arcade.overlap(platforms, redBalloon, overlapRed);
    game.physics.arcade.overlap(platforms, yellowBalloon, overlapYellow); 
    if (player)
    {
        player.body.velocity.setTo(0, 0);

        if (cursors.left.isDown)
        {
            player.body.velocity.x = -400;
        }
        else if (cursors.right.isDown)
        {
            player.body.velocity.x = 400;
        }

        if (cursors.up.isDown)
        {
            fireDart();

        }
    
     }
}


function fireDart () {
    if (game.time.now > dartTime)
    {
        dart = darts.getFirstExists(false);
        dart.scale.x = .70;
        dart.scale.y = .70;
        if (dart)
        {
            // dart.kill();  
            dart.reset(player.x, player.y + 8);
            dart.body.velocity.y = -400;
            dartTime = game.time.now + 500;
        }
    }

}
function createBlueBalloon(){
    setInterval(function(){
        blueBalloons = blueBalloon.create(Math.random()*450,-100,'blueBalloon');
        blueBalloons.body.gravity.y = 60;
    },3000)
}
function createRedBalloon(){
    setInterval(function(){
        redBalloons = redBalloon.create(Math.random()*450,-100,'redBalloon');
        redBalloons.body.gravity.y = 50;
      
    },4000)
}
function createYellowBalloon(){
    setInterval(function(){
        yellowBalloons = yellowBalloon.create(Math.random()*450,-100,'yellowBalloon');
        yellowBalloons.body.gravity.y = 20;
       
    },5000)
}
// function createGranada(){
//     setInterval(function(){
//         granadas = granada.create(Math.random()*450,-100,'granada');
//         granadas.body.gravity.y = 180;
//         granadas.scale.x = .2;
//         granadas.scale.y = .2;

       
//     },7000)
// }

function collectRed (player, redBalloon) {
    score += 10;
    player.kill();
    redBalloon.kill();
    var explode = explodesR.getFirstExists(false);
    explode.reset(redBalloon.body.x-6, redBalloon.body.y-3);
    explode.play('boom', 20, false, true);
    if(getData() <= score){
        saveData(score); 
        bestText.text ="Best: "+score;
    }
    scoreText.text = 'Score: ' +score;

}
function collectYellow (player, yellowBalloon) {
 score += 10;
    player.kill();
    yellowBalloon.kill();
     var explode = explodesY.getFirstExists(false);
    explode.reset(yellowBalloon.body.x-6, yellowBalloon.body.y-3);
    explode.play('yboom', 20, false, true);
    if(getData() <= score){
        saveData(score); 
        bestText.text ="Best: "+score;
    }
    scoreText.text = 'Score: ' +score;
}
function collectBlue (player, blueBalloon) {
    score += 10;
    player.kill();
    blueBalloon.kill(); 
    var explode = explodesB.getFirstExists(false);
    explode.reset(blueBalloon.body.x-6, blueBalloon.body.y-3);
    explode.play('bboom', 20, false, true);

    if(getData() <= score){
        saveData(score); 
        bestText.text ="Best: "+score;
    }
    scoreText.text = 'Score: ' +score;
}
// function collectGranada (player, granada) {
//     // for (x == score)score --;
//     granada.kill();
//     player.kill();
//     var explode = explodesG.getFirstExists(false);
//     explode.reset(granada.body.x-6, granada.body.y-3);
//     explode.play('granade',16, false, true);
//     restart();

 
//     game._paused = true;
//     gameOverText.text = "Game Over!\nHigh Score: "+getData()+"\nYour Score: "+score;
    

// }

function overlapRed (platforms, redBalloon) {
    player.kill();
    game._paused = true;
    gameRestartText .text = "\t\t\tTap to Restart\n\n\n" ;  
    gameOverText.text = "Game Over!\nHigh Score: "+getData()+"\nYour Score: "+score;
    restart();
   
        // gameOverText.visible = true;
        // game.input.onDown.add(restart,this);
}

function overlapYellow (platforms, yellowBalloon) {

    player.kill();
    game._paused = true;
    gameRestartText .text = "\t\t\tTap to Restart\n\n\n" ;  
    gameOverText.text = "Game Over!\nHigh Score: "+getData()+"\nYour Score: "+score;
    restart();

    // gameOverText.visible = true;
        // game.input.onTap.addOnce(restart,this);
}

function overlapBlue (platforms, blueBalloon) {

    player.kill();
    game._paused = true;
    gameRestartText .text = "\t\t\tTap to Restart\n\n\n" ;  
    gameOverText.text = "Game Over!\nHigh Score: "+getData()+"\nYour Score: "+score;
    restart();

    // gameOverText.visible = true;
        // game.input.onTap.addOnce(restart,this);

}

function right(){
    setTimeout(function(){
        console.log ("x");
        buttonRight.frame = 0;

    },200)
    buttonRight.frame = 1;
    player.body.velocity.x = 4000;
    
}
function left(){
    setTimeout(function(){
        console.log ("x");
        buttonLeft.frame = 0;
    },200)
    buttonLeft.frame = 1;
    player.body.velocity.x = -4000;
}
function fire(){
    setTimeout(function(){
        console.log ("x");
        fireButton.frame = 0;
    },200)
    fireButton.frame = 1;
    fireDart();
}
function restart(){
    game.state.start(game.state.current);


}

// function pause(){
//     setTimeout(function(){
//         console.log ("x");
//         pause.frame = 0;
//         // game._paused = true;

//     },200)
//     pause.frame = 1;
//     // game._paused = false;
//     // play();
// }
// function pause() {

//     if (flag)
//     {
//         tween.pause();
//     }
//     else
//     {
//         tween.resume();
//     }

//     flag = !flag;

// }

// }


function saveData(score){
    localStorage.setItem("gameData", score); 

}
function getData(){
    return (localStorage.getItem("gameData") == null || localStorage.getItem("gameData") == "")?0: localStorage.getItem("gameData");
}
