var w = 500; var h = 600;
var player, cursors,dart,darts;
var redBalloons, redBalloon,yellowBalloons,yellowBalloon,blueBalloons,blueBalloon,scoreText,gameOverText, bestText,bullets,fireButton, buttonRight, buttonLeft;
var score = 0,dartTime = 0;
var game = new Phaser.Game(w, h, Phaser.CANVAS, '', { preload: preload, create: create, update: update});

function preload() {

    game.load.image('sky', 'assets/background.png');
    game.load.image('ground', 'assets/platform.png');
    game.load.image('redBalloon', 'assets/redBalloon.png');
    game.load.image('yellowBalloon', 'assets/yellowBalloon.png');
    game.load.image('blueBalloon', 'assets/blueBalloon.png');
    game.load.image('dart', 'assets/dart.png');
    game.load.image('player1', 'assets/dart.png');
    game.load.spritesheet('right', 'assets/right.png', 128, 128);
    game.load.spritesheet('left', 'assets/left.png', 128, 128);
    game.load.spritesheet('fire', 'assets/fire2.png', 128, 128);
}


function create() {
    game.physics.startSystem(Phaser.Physics.ARCADE);

    game.add.sprite(0, 0, 'sky');
    buttonRight = game.add.button(150, 500, 'right', right);
    buttonRight.scale.x = .6;
    buttonRight.scale.y = .6;
    buttonLeft = game.add.button(45, 500, 'left', left);
    buttonLeft.scale.x = .6;
    buttonLeft.scale.y = .6;
    fireButton = game.add.button(380, 500, 'fire', fire);
    fireButton.scale.x = .6;
    fireButton.scale.y = .6;

    blueBalloon = game.add.sprite("blueBalloon");
    redBalloon = game.add.sprite("redBalloon");
    yellowBalloon = game.add.sprite("yellowBalloon");
    platforms = game.add.group();
    platforms.enableBody = true;
    var ledge = platforms.create(0, 450, 'ground');
    ledge.body.immovable = true;
    ledge.scale.x = 1.25;
    ledge.scale.y = .2;
    darts = game.add.group();
    darts.enableBody = true;
    darts.createMultiple(30, 'dart');
    darts.setAll('anchor.x', 0.5);
    darts.setAll('anchor.y', 1);
    game.physics.arcade.enable(darts);
    game.physics.arcade.enable(redBalloon);
    game.physics.arcade.enable(yellowBalloon);
    game.physics.arcade.enable(blueBalloon);

    player = game.add.sprite(w/2, game.world.height - 120, 'player1');
    player.scale.x = .60;
    player.scale.y = .60;
    player.anchor.setTo(0.5, 0.5);
    game.physics.arcade.enable(player);

    cursors = game.input.keyboard.createCursorKeys();
    blueBalloon= game.add.group();
    blueBalloon.enableBody = true;
    redBalloon = game.add.group();
    redBalloon.enableBody = true;
    yellowBalloon = game.add.group();
    yellowBalloon.enableBody = true;
    
    createBlueBalloon();
    createRedBalloon();
    createYellowBalloon();

    scoreText = game.add.text(16, 460, 'Score: 0', { fontSize: '1px', fill: 'white'});
    scoreText.scale.x = .80;
    scoreText.scale.y = .80;
    bestText = game.add.text(380,460, 'Best: '+getData()   ,{fontSize:'1px', fill: 'red'});
    bestText.scale.x = .80;
    bestText.scale.y = .80;

    gameOverText = game.add.text((w/2)-50,(h/2)-60,"");
    // gameOverText.scale.x = .80;
    // gameOverText.scale.y = .80;

}

function update() {

    game.physics.arcade.collide(player, blueBalloons);
    game.physics.arcade.collide(player, redBalloons);
    game.physics.arcade.collide(player, yellowBalloons);
    // game.physics.arcade.collide(redBalloons, yellowBalloons);
    // game.physics.arcade.collide(yellowBalloons, blueBalloons);
    // game.physics.arcade.collide(blueBalloons, platforms);
    // game.physics.arcade.collide(yellowBalloons, platforms);
    // game.physics.arcade.collide(redBalloons, platforms);
    game.physics.arcade.overlap(dart, blueBalloon, collectBlue);
    game.physics.arcade.overlap(dart, redBalloon, collectRed);
    game.physics.arcade.overlap(dart, yellowBalloon, collectYellow);

    game.physics.arcade.overlap(platforms, redBalloon,overlapRed);
    game.physics.arcade.overlap(platforms, blueBalloon,overlapBlue);
    game.physics.arcade.overlap(platforms, yellowBalloon,overlapYellow);
   
    
    if (player)
    {
        player.body.velocity.setTo(0, 0);

        if (cursors.left.isDown)
        {
            player.body.velocity.x = -400;
        }
        else if (cursors.right.isDown)
        {
            player.body.velocity.x = 400;
        }

        if (cursors.up.isDown)
        {
            fireDart();

        }
     }
}


function fireDart () {
    if (game.time.now > dartTime)
    {
        dart = darts.getFirstExists(false);
        dart.scale.x = .60;
        dart.scale.y = .60;
        if (dart)
        {
            // dart.kill();  
            dart.reset(player.x, player.y + 8);
            dart.body.velocity.y = -400;
            dartTime = game.time.now + 200;
        }
    }

}
function createBlueBalloon(){
    setInterval(function(){
        var blueBalloons = blueBalloon.create(Math.random()*w,0,'blueBalloon');
        blueBalloons.body.gravity.y = 20;
    },3000)
}
function createRedBalloon(){
    setInterval(function(){
        var redBalloons = redBalloon.create(Math.random()*w,0,'redBalloon');
        redBalloons.body.gravity.y = 30;
      
    },4000)
}
function createYellowBalloon(){
    setInterval(function(){
        var yellowBalloons = yellowBalloon.create(Math.random()*w,0,'yellowBalloon');
        yellowBalloons.body.gravity.y = 10;
       
    },5000)
}

function collectRed (player, redBalloon) {
    score += 10;
    player.kill();
    redBalloon.kill();
    if(getData() <= score){
        saveData(score); 
        bestText.text ="Best: "+score;
    }
    scoreText.text = 'Score: ' +score;
}
function collectYellow (player, yellowBalloon) {
 score += 10;
    player.kill();
    yellowBalloon.kill();
    if(getData() <= score){
        saveData(score); 
        bestText.text ="Best: "+score;
    }
    scoreText.text = 'Score: ' +score;
}
function collectBlue (player, blueBalloon) {
    score += 10;
    player.kill();
    blueBalloon.kill();
    if(getData() <= score){
        saveData(score); 
        bestText.text ="Best: "+score;
    }
    scoreText.text = 'Score: ' +score;
}

function overlapRed (platforms, redBalloon) {
    player.kill();
    gameOverText.text = "Game Over!";
    game._paused = true;
        // gameOverText.visible = true;

        //the "click to restart" handler
        // game.input.onTap.addOnce(restart,this);
}

function overlapYellow (platforms, yellowBalloon) {

    player.kill();
    gameOverText.text = "Game Over!";
    game._paused = true;
}

function overlapBlue (platforms, blueBalloon) {

    player.kill();
    gameOverText.text = "Game Over!";
    game._paused = true;
}
function restart () {

    // redBalloons.removeAll();
    // createRedBalloons/();

    player.revive();
    gameOverText.visible = false;

}
function right(){
    player.body.velocity.x = 400;
    // setTimeout(function(){
    //     console.log ("x");
    //     right.frame = 0;
    // },3000)
    // right.frame = 1;
}
function left(){
    player.body.velocity.x = -400;
    // setTimeout(function(){
    //     console.log ("x");
    //     right.frame = 0;
    // },3000)
    // right.frame = 1;
}
function fire(){
    fireDart();
    // setTimeout(function(){
    //     console.log ("x");
    //     right.frame = 0;
    // },3000)
    // right.frame = 1;
}


function saveData(score){
    localStorage.setItem("gameData", score); 

}
function getData(){
    return (localStorage.getItem("gameData") == null || localStorage.getItem("gameData") == "")?0: localStorage.getItem("gameData", bestText);
}